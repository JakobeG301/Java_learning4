
public class Metody1 {

	public static void main(String[] args) {
		
		double x = 3.14;
		double y = -10;
		double z = Math.min(x, y);
		System.out.println(z);
		double w = Math.max(x, y);
		System.out.println(w);
		double a = Math.abs(y);
		System.out.println(a);
		double b = Math.sqrt(x);
		System.out.println(b);
		double c = Math.round(x);
		System.out.println(c);
		double d = Math.ceil(x);
		System.out.println(d);
		double e = Math.floor(x);
		System.out.println(e);
		

	}

}
