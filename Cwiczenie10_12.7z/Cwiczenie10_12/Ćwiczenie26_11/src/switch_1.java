import java.util.Scanner;


public class switch_1 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("wybór: ");
		int choiceI = Integer.parseInt(scanner.nextLine()); 
		
		switch (choiceI) {
		
		case 1: System.out.println("Wybrałeś 1 :)");
		break;
		case 2: System.out.println("Nie można mieszac JOptionPane ze scannerem :/");;
		break;
		default: System.out.print("Error");
		}
		
		
	}
	
}
