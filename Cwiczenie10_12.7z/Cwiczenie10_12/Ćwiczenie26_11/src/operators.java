
public class operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int przyjaciele = 10;
	int przyjaciele2 = przyjaciele /3;
	
	System.out.println(przyjaciele2);
			
	double przyjaciele3 = (double) przyjaciele / 3;
	System.out.println(przyjaciele3);
	
	
	
}
}
