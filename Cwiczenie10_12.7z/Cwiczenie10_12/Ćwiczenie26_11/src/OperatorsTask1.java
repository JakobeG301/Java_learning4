
import javax.swing.JOptionPane;
public class OperatorsTask1 {

	public static void main(String[] args) {
		
		
		
		
		
		
		
	}
}
