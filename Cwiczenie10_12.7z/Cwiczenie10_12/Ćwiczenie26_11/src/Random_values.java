import java.util.Random;

public class Random_values {

	public static void main(String[] args)
	{
		
		Random random = new Random();
		
		
		int first_random = random.nextInt(6)+1;
		System.out.println(first_random);
		double second_random = random.nextDouble(10)+1;
		boolean third_random = random.nextBoolean();
		System.out.println(second_random);
		System.out.println(third_random);
	}
}
