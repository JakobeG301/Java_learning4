import javax.swing.JOptionPane;
public class while_loop {

	public static void main(String[] args) {
		int item = 0;
		boolean klucz = false;
		
		while(!klucz==true) {
			
			//Pokój
			
			int room = Integer.parseInt(JOptionPane.showInputDialog("Pokoj - gdzie chcesz zajrzec?\n 1. Szafka \n 2. Stoł \n 3. Pod łozko \n 4. Chce wyjsc")); 
		
				//Szafka
		 	
		switch (room)
		 	{
		 	case 1:  
			 item = Integer.parseInt(JOptionPane.showInputDialog("Co wybierasz? W szafce znajduje sie:\n 1. Skarpetka\n 2.Klucz"));
			 	switch (item) {
			 	
			 	case 1: item = 11;
			 	JOptionPane.showMessageDialog(null, "Zebrano skarpetke!");
			 	break;
			 
			 	case 2: item = 12;
			 	klucz = true; 
			 	JOptionPane.showMessageDialog(null, "Zebrano Klucz!");
			 	break;
			 	default: JOptionPane.showMessageDialog(null, "Rozejrze się gdzie indziej");
			 	}
				break;
			 	//Stół
			 	
			case 2:  
			 item = Integer.parseInt(JOptionPane.showInputDialog("Co wybierasz? Na stole znajduja sie:\n 1. Gazeta\n 2. Kubek"));
				switch (item) {
					 	
				case 1: item = 11;
			 	JOptionPane.showMessageDialog(null, "Zebrano gazete!");
			 	break;
			 
			 	case 2: item = 12;
			 	JOptionPane.showMessageDialog(null, "Zebrano kubek!");
			 	break;
				default: JOptionPane.showMessageDialog(null, "Rozejrze się gdzie indziej"); 
				}
			 	break;
				
				
			case 3:  
			 item = Integer.parseInt(JOptionPane.showInputDialog("Co wybierasz? W szafce znajduje sie:\n 1. Koc \n 2.Stara bielizna"));
				switch (item) {
					 	
				case 1: item = 11;
			 	JOptionPane.showMessageDialog(null, "Zebrano koc!");
			 	break;
				
				 case 2:
			 	JOptionPane.showMessageDialog(null, "Fuj! nie bede tego podnosil");
			 	break;
				default: JOptionPane.showMessageDialog(null, "Rozejrze się gdzie indziej"); 
				}
				break;			
			
			case 4: JOptionPane.showMessageDialog(null, "Brak klucza! Żeby wyjść, znajdz klucz.");
			break;
				
				default: JOptionPane.showMessageDialog(null, "[Error] bledna wartosc!"); 
		 	}
		if (klucz == true) {JOptionPane.showMessageDialog(null, "Dzwi otwarte. Dowidzienia");}
			
		 	}
		 

		 	
		 
		 
		 
		
		
	}
	
	
}
