import java.util.Scanner;

public class logical_operators {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Grasza dalej? Jeśli nie to wciśniej q lub Q");
		String imie = scanner.nextLine();
		
		if(!imie.equals("q")&&!imie.equals("Q")) {
			System.out.println("zostajesz");
		}
		else {
			System.out.println("wychodzisz");
		}
		
		
		
		
		
	};
}
