import javax.swing.JOptionPane;

public class hypotenuse_pitagoras {
	
	public static void main(String[] args) {

	int choice = Integer.parseInt(JOptionPane.showInputDialog("Co chcesz obliczyć?\n	1. Trójkąt - bok c\n	2. Promień okręgu z jego obwodu"));
	double pi = 3.14;
	
	if (choice == 1)
	{
		//Pobranie wartosci boku a i b
		String first = JOptionPane.showInputDialog("Jaka jest długość pierwszego boku trójkąta(cm)?");
		String second = JOptionPane.showInputDialog("Jaka jest długość drugiego trójkąta trójkąta(cm)?");
		//Zamiana typu pobranych stringow na double by móc wykonywać na nich oblicznia
		double firstD = Double.parseDouble(first);
		double secondD = Double.parseDouble(second);
		//Obliczenie i wyswietlenia boku c za pomocą wzoru pitagorasa
		double thirdD = Math.sqrt((firstD*firstD)+(secondD*secondD));
		
		JOptionPane.showMessageDialog(null, "Długość trzeciego boku wynosi " + thirdD + " cm");
	
	}
	//wybranie opcji nr 2 - obliczanie promienia okręgu z obwodu okręgu
	else if (choice == 2)
	{
		
		double obwod = Double.parseDouble(JOptionPane.showInputDialog("Jaka jest obwód okręgu?"));
		double promien = obwod/6.28;
		
		JOptionPane.showMessageDialog(null, "promień okregu o obwodzie "+obwod+ " wynosi "+ promien + " cm");
	}
	//Error message - zla wartosc
	else
		JOptionPane.showMessageDialog(null, "[Error] Zła wartość");
	}
}
