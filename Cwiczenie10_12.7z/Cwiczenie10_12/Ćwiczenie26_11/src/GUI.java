import javax.swing.JOptionPane;
public class GUI {

	public static void main(String[] args) {
		String nazwa = JOptionPane.showInputDialog("Podaj nazwę");
		JOptionPane.showMessageDialog(null, "Cześć " + nazwa);
		
		int wiek = Integer.parseInt(JOptionPane.showInputDialog("Podaj wiek"));
		JOptionPane.showMessageDialog(null, "Twój wiek to: " + wiek);
		
		double wzrost = Double.parseDouble(JOptionPane.showInputDialog("Podaj swój wzrost"));
		JOptionPane.showMessageDialog(null, "Twój wzrost to: " + wzrost);
		
		
		
		
		
	}

}
